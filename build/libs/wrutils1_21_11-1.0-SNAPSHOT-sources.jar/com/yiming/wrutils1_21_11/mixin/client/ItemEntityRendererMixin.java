package com.yiming.wrutils1_21_11.mixin.client;

import com.yiming.wrutils1_21_11.client.Wrutils1_21_11Client;
import net.minecraft.class_10039;
import net.minecraft.class_1542;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_9064;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * 让掉落物在头顶显示其实体数字 ID，可用 I 键开关。
 *
 * <p>原版 {@code EntityRenderer.updateRenderState} 只在 {@code hasLabel(...)} 成立时才写入
 * {@code state.displayName} / {@code state.nameLabelPos}，掉落物默认不满足该条件，因此默认不显示名字。
 * 而 {@code EntityRenderer.render} 是无条件调用 {@code renderLabelIfPresent} 的，后者只判断
 * {@code displayName != null}。所以这里在渲染状态更新完成后补写这两个字段，即可复用原版的整条标签
 * 渲染链路（billboard、缩放、背景、光照），无需自行绘制文本。
 */
@Mixin(class_916.class)
public class ItemEntityRendererMixin {

    @Inject(
            method = "updateRenderState(Lnet/minecraft/entity/ItemEntity;Lnet/minecraft/client/render/entity/state/ItemEntityRenderState;F)V",
            at = @At("TAIL")
    )
    private void wrutils$showEntityId(class_1542 entity, class_10039 state, float tickDelta, CallbackInfo ci) {
        if (!Wrutils1_21_11Client.showItemEntityId) {
            return;
        }
        class_243 labelPos = entity.method_56072()
                .method_55675(class_9064.field_47745, 0, entity.method_61415(tickDelta));
        if (labelPos != null) {
            state.field_53337 = class_2561.method_43470(String.valueOf(entity.method_5628()));
            state.field_53338 = labelPos;
        }
    }
}
