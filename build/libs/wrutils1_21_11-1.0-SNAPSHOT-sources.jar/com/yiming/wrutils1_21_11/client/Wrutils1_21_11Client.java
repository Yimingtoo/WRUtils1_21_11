package com.yiming.wrutils1_21_11.client;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class Wrutils1_21_11Client implements ClientModInitializer {

    /** 是否在掉落物头顶显示实体数字 ID，由 I 键切换。 */
    public static boolean showItemEntityId = true;

    @Override
    public void onInitializeClient() {
        class_304 toggleKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.wrutils1_21_11.toggle_item_entity_id",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_I,
                class_304.class_11900.field_62556));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.method_1436()) {
                showItemEntityId = !showItemEntityId;
            }
        });
    }
}
